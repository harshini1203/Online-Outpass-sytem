<?php

require_once('tcpdf/tcpdf.php');
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';


$mail = new PHPMailer\PHPMailer\PHPMailer();



// Start session
session_start();

// Check if user is logged in
if (isset($_SESSION["username"])) {
    $email = $_SESSION["username"];
} else {
    echo 'error';
    exit();
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "pass123";
$dbname = "db2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Query to retrieve data from the database
$sql = "SELECT * FROM student WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

$sql2 = "SELECT * FROM outpass WHERE email = '$email'";
$result2 = mysqli_query($conn, $sql2);

// Initialize the HTML content
$html = '<h1>Outpass</h1>';

// Loop through the query results and add the data to the HTML
if ($result && mysqli_num_rows($result) > 0 && $result2 && mysqli_num_rows($result2) > 0) {
    $row = mysqli_fetch_assoc($result);
    $row2 = mysqli_fetch_assoc($result2);
  //   $data2 = array(
  //     array('Outpass no. ', ''.$row2["out_no"].''),
  //     array('Name', ''.$row["name"].''),
  //     array('Registration Number', ''.$row["regno"].''),
  //     array('Branch ', ' '.$row["branch"].''),
  //     array('Hostel no.', ''.$row["hostel_no"].''),
  //     array('Room no.', ''.$row["room_no"].''),
  //     array(' Year of Study', ''.$row["year"].''),
  //     array('From date', ''.$row2["go_date"].''),
  //     array('Return date ', ' '.$row2["return_date"].''),
  //     array('Reason ', ''.$row2["reason"].'')  
  // );
  // Set the HTML content with CSS styles for the table

$html = '<style>
table ,th, td {
  border: 1px solid grey;
  border-collapse: collapse;
  font-weight: bold;
  
}
.tab{
  position: absolute;
  top:220px;
  left:150px;
  margin: 0px;
  background:linear-gradient(to bottom,#898aa6,#c9bbcf);
}

</style>
<h1 style="color: black; font-size: 20px; text-align: center;">Outpass details</h1>
<div style="background-color:#898aa6;">
<table cellpadding="5" cellspacing="5">

<tbody>
    <tr>
    <th>Outpass no. </th>
    <td>'.$row2["out_no"].'</td>
    </tr>
    <tr>
        <th>Name</th>
        <td>'.$row["name"].'</td>
    </tr>
    <tr>
        <th>Registration Number</th>
        <td>'.$row["regno"].'</td>
    </tr>
    <tr>
        <th>Branch </th>
        <td>'.$row["branch"].'</td>
    </tr>
    <tr>
        <th>Hostel no.</th>
        <td>'.$row["hostel_no"].'</td>
    </tr>
    <tr>
        <th>Room no.</th>
        <td>'.$row["room_no"].'</td>
    </tr>
    <tr>
        <th>Year of study</th>
        <td>'.$row["year"].'</td>
    </tr>
    <tr>
        <th>From date</th>
        <td>'.$row2["go_date"].'</td>
    </tr>
    <tr>
        <th>From date</th>
        <td>'.$row2["go_date"].'</td>
    </tr>
    <tr>
        <th>Return date</th>
        <td>'.$row2["return_date"].'</td>
    </tr>
    <tr>
        <th>Reason</th>
        <td>'.$row2["reason"].'</td>
    </tr>
    
</tbody>
</table>
</div>
<br>
<br>';

// Add the HTML content to a cell in the PDF
// $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, false, true, '');

 

} else {
    $html .= '<p>No results found.</p>';
}

// Generate QR code
require_once 'C:\xampp\htdocs\project\phpqrcode-master\qrlib.php';

// Create a unique identifier for the QR code
$item_id = $row2['out_no'];

// Define the URL you want to embed
$url = 'https://www.example.com/';

// Generate QR code with timestamp and URL
$data = $item_id . '_' . time() . '_' . $url;
QRcode::png($data, 'qrcode.png', 'H', 3, 2);


// Display the QR code on the page
$html .= '<img src="qrcode.png" alt="QR code" />';



// Create a new PDF document
$pdf = new TCPDF();

// Set the document information
$pdf->SetCreator('Your Name');
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('Student Outpass');

// Add the HTML content to the PDF
$pdf->AddPage();
$pdf->SetFillColor(173, 216, 230); // Set the background color to red

$pdf->writeHTML($html, true, false, true, false, '');
// foreach ($data2 as $row) {
//   // Loop through each column in the row and add it to the table
//   foreach ($row as $col) {
//       $pdf->MultiCell($table_width/count($header), $cell_padding, $col, 1, 'C', 0, 0);
//   }
//   // Add a new line after each row
//   $pdf->Ln();
// }
$temp_dir = sys_get_temp_dir();
$pdf_file = $temp_dir . '/document.pdf';
$pdf->Output($pdf_file, 'I');


// Output the PDF to the browser or save it to a file
//$pdf->Output('user_details.pdf', 'I');





//to send pdf as mail
$mail = new PHPMailer\PHPMailer\PHPMailer;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'harshinimanivannan@gmail.com';
$mail->Password = 'Kamala@73';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;


//set the email message properties, such as the sender, recipient, subject, and body.

$mail->setFrom('harshinimanivannan@gmail.com', 'Your Name');
$mail->addAddress($email, $row["name"]);
$mail->Subject = 'Outpass';
$mail->Body = 'Please find attached a PDF document.';


// attach the PDF file to the email message
$mail->addAttachment($pdf_file);

if(isset($_POST['send_email_button'])) {
  if(!$mail->send()) {
      echo 'Message could not be sent.';
      echo 'Mailer Error: ' . $mail->ErrorInfo;
  } else {
      echo 'Message sent successfully';
  }
}

$conn->close();
?>




<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
  setInterval(function() {
    $.ajax({
      url: 'scan-qr.php',
      data: { data: 'php echo $data; ' },
      success: function(result) {
        if (result == 'success') {
          // QR code has been scanned
          alert('QR code has been scanned!');
        }
      }
    });
  }, 5000); // Check every 5 seconds
});
</script> -->
