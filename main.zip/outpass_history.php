<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
  <title>dashboard-home</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="dashboard-home.php?v=<?php echo time(); ?>">DASHBOARD</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a href="login.php?v=<?php echo time(); ?>"><button class="btn btn-primary"
              id="login-button">Logout</button></a>
        </li>
      </ul>
    </div>
  </nav>

  <?php
session_start();
$email = $_SESSION["username"];
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "pass123";
$dbname = "db2";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT out_no, email, go_date, return_date, reason, status FROM outpass where email='$email' and status in ('Approved','Denied')";
$go_day = "select DAYNAME(go_date) from outpass";
$come_day = "select DAYNAME(return_date) from outpass";
$result = $conn->query($sql);
$goday = $conn->query($go_day);
$comeday = $conn->query($come_day);

// Display the data in an HTML table
if ($result->num_rows > 0) {
  echo "<table id=history>";
  echo "<tr><th>Outpass No</th>
        <th>Date of Leaving</th>
        <th>Date of Returning</th>
        <th>Reason</th>
        <th>Status</th>
        <th>View/edit</th>
        </tr>";

  while($row = $result->fetch_assoc()) {
    $go_day_name = $goday->fetch_row()[0];
    $come_day_name = $comeday->fetch_row()[0];
    echo "<tr><td>" . $row["out_no"] . "</td><td>" . $row["go_date"]." - " .$go_day_name. "</td><td>" . $row["return_date"]." - ".$come_day_name . "</td><td>" . $row["reason"] . "</td><td>" . $row["status"] . "</td><td><a href='view_outpass.php?out_no=" . $row["out_no"] . "'>View/Edit</a>";
  }
  echo "</table>";
} else {
  echo "None of your outpasses are approved yet!";
}

// Close the database connection
$conn->close();
?>


  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>