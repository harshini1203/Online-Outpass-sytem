<?php
echo "ready to connect <br>";
$servername = "localhost";
$username = "root";
$password = "pass123";

$conn = mysqli_connect($servername, $username, $password);

if(!$conn){
    die("Could not connect".mysqli_connect_error());
}
else{
    echo "connection was established";
}

?>
