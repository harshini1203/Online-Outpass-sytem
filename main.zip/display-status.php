<?php

$email = $_SESSION["username"];
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "pass123";
$dbname = "db2";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT out_no, email, go_date, return_date, reason, status FROM outpass where email='$email' and status='Waiting'";
$go_day = "select DAYNAME(go_date) from outpass";
$come_day = "select DAYNAME(return_date) from outpass";
$result = $conn->query($sql);
$goday = $conn->query($go_day);
$comeday = $conn->query($come_day);

// Display the data in an HTML table
if ($result->num_rows > 0) {
  echo "<table>";
  echo "<tr><th>Outpass No</th>
        <th>Date of Leaving</th>
        <th>Date of Returning</th>
        <th>Reason</th>
        <th>Status</th>
        <th>View/edit</th>
        </tr>";

  while($row = $result->fetch_assoc()) {
    $go_day_name = $goday->fetch_row()[0];
    $come_day_name = $comeday->fetch_row()[0];
    echo "<tr><td>" . $row["out_no"] . "</td><td>" . $row["go_date"]." - " .$go_day_name. "</td><td>" . $row["return_date"]." - ".$come_day_name . "</td><td>" . $row["reason"] . "</td><td>" . $row["status"] . "</td><td><a href='view_outpass.php?out_no=" . $row["out_no"] . "'>View/Edit</a>";
  }
  echo "</table>";
} else {
  echo "You haven't filled any outpasses yet!";
}

// Close the database connection
$conn->close();
?>
