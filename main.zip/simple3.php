<?php
$conn= new mysqli("localhost","root","pass123","db2");
   $sql="update outpass set status='Approved' where status='Waiting'";
   $conn->query($sql);

?>
