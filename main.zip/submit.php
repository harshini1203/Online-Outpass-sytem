<?php
session_start();
$purpose = $_POST["purpose"];
$date1 = $_POST["go_date"];
$date2 = $_POST["return_date"];
$email = $_SESSION["username"];

$servername = "localhost";
$username = "root";
$password = "pass123";
$dbname = "db2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed" . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT * FROM outpass WHERE email = ? AND go_date = ?");
$stmt->bind_param('ss', $email, $date1);
$stmt->execute();
$stmt->store_result();
// If the SELECT statement returns a row, then the user has already filled a form for this go_date
if ($stmt->num_rows > 0) {
    session_start();
    $_SESSION['alert'] = "You cannot take more than one outpass for the same date!";
} else {
    $sql = "INSERT INTO outpass (reason,go_date,email,return_date) VALUES ('$purpose','$date1','$email','$date2')";

    if (mysqli_query($conn, $sql)) {
        session_start();
        $_SESSION['alert'] = "Outpass filled successfully.";
    }
}


header("Location: dashboard-home.php");

mysqli_close($conn);
?>