<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
  <title>dashboard-home</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">DASHBOARD</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a href="login.php?v=<?php echo time(); ?>"><button class="btn btn-primary"
              id="login-button">Logout</button></a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-4">
        <button class="btn btn-primary btn-block">Out-pass Status</button>
      </div>
      <div class="col-md-4">
        <a href="fill-form.php?v=<?php echo time(); ?>"><button class="btn btn-primary btn-block">Create new
            form</button></a>
      </div>
      <div class="col-md-4">
        <a href="outpass_history.php?v=<?php echo time(); ?>"><button class="btn btn-primary btn-block">Out-pass History</button></a>
      </div>
    </div>
  </div>

  <div id="welcome-message">
    <?php include 'display-name.php'; ?>
    <?php echo $message; ?>
  </div>

  <?php
  if (isset($_SESSION['alert'])) {
    echo "<script>alert('" . $_SESSION['alert'] . "')</script>";
    // Clear the session variable to avoid displaying the same message again
    unset($_SESSION['alert']);
  }
  ?>

  <div id="display-status">
    <?php include 'display-status.php'; ?>
  </div>


  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>