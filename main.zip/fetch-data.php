<?php
// Connect to your database
$servername = "localhost";
$username = "root";
$password = "pass123";
$dbname = "db2";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Retrieve data based on register number
$regno = $_POST['regno'];

$sql = "SELECT name, branch, hostel_no, room_no,year,regno FROM student WHERE regno = $regno";
$result = $conn->query($sql);

// Check if data exists
if ($result->num_rows > 0) {
  // Output data of each row
  while($row = $result->fetch_assoc()) {
    $name = $row["name"];
    $branch = $row["branch"];
    $hostel_no = $row["hostel_no"];
    $room_no = $row["room_no"];
    $year = $row["year"];
  }
} else {
  echo "0 results";
}

// Close database connection
$conn->close();

// Return data as JSON object
$data = array("name" => $name, "branch" => $branch, "hostel_no" => $hostel_no, "room_no" => $room_no, "year" => $year,"regno" => $regno);
echo json_encode($data);
?>