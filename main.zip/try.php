<html>
<head>
</head>
<body>
    <?php
$con=new mysqli("localhost","root","pass123","db2");
$query="select image from student where name='A Shama Anjum'";
$result=$con->query($query);

if($result->num_rows>0){
    while($row=$result->fetch_assoc()){
        $image_type = pathinfo($row["image"], PATHINFO_EXTENSION);
                   $image_data = file_get_contents($row["image"]);
                  $image_base64 = 'data:image/' . $image_type . ';base64,' . base64_encode($image_data);
                  $s="img";
                  echo'<img src="data:image/jpeg;base64,<?php echo $image_base64; ?>" alt="Student image" width="150"
                  height="150" />';
                  
                  
        //print_r($row['image']);
        
    }
}
?>
<script>
              // Set the src of the image to the base64 encoded string
              var studentImage = document.querySelector('img');
              studentImage.src = '<?php echo $image_base64; ?>';
            </script>
</body>

</html>