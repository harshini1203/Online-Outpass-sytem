<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "pass123";
$dbname = "db2";

$email = '';
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed" . $conn->connect_error);
}

// Retrieve the email from the login form
$email = $_SESSION["username"];

// Query the student table to retrieve the name of the student with the matching email
$query = "SELECT name FROM student WHERE email = '$email'";
$result = mysqli_query($conn, $query);

// If the query returns a result, retrieve the name and display the welcome message
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    $message = "Welcome, $name!";
} else {
    $message = "Invalid email or password.";
}
?>