<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
  <title>fill form</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="dashboard-home.php?v=<?php echo time(); ?>">DASHBOARD</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a href="login.php?v=<?php echo time(); ?>"><button class="btn btn-primary"
              id="login-button">Logout</button></a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-4">
        <a href="dashboard-home.php?v=<?php echo time(); ?>" type="button" class="btn btn-secondary btn-block mb-3"><i
            class="fas fa-arrow-left mr-2"></i>Back</a>
        <!-- submit button later -->
        <form method="POST" action="save_outpass.php?out_no='<?php echo $_GET["out_no"]; ?>'">

          <?php
          session_start();
          $out_no = $_GET["out_no"];

          $servername = "localhost";
          $username = "root";
          $password = "pass123";
          $dbname = "db2";
          $conn = new mysqli($servername, $username, $password, $dbname);

          if ($conn->connect_error) {
            die("Connection failed" . $conn->connect_error);
          }

          $sql = "SELECT email from outpass where out_no = '$out_no'";
          $result = $conn->query($sql);
          if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
              $email = $row["email"];
            }
          }

          $sql1 = "SELECT s.name, s.branch, s.image, s.hostel_no, s.room_no, s.regno, s.year, o.out_no, o.go_date, o.return_date, o.reason FROM student s INNER JOIN outpass o ON s.email = o.email WHERE s.email = '$email' AND o.out_no = '$out_no'";
          $result1 = $conn->query($sql1);
          if ($result1->num_rows > 0) {
            // Output data of each row
            while ($row = $result1->fetch_assoc()) {
              $name = $row['name'];
              $branch = $row['branch'];
              $hostelno = $row['hostel_no'];
              $roomno = $row['room_no'];
              $year = $row['year'];
              $go_date = $row['go_date'];
              $return_date = $row['return_date'];
              $reason = $row['reason'];
              $image = $row['image'];
              $regno = $row['regno'];
            }
          }
          $image_type = pathinfo($image, PATHINFO_EXTENSION);
          $image_data = file_get_contents($image);
          $image_base64 = 'data:image/' . $image_type . ';base64,' . base64_encode($image_data);

          $conn->close();

          // Output data as a JSON object directly into the JavaScript code
          echo "<script>
        window.addEventListener('load', function() {
            var out_no = " . $out_no . ";
            var data = {
                name: '" . $name . "',
                branch: '" . $branch . "',
                hostel_no: '" . $hostelno . "',
                room_no: '" . $roomno . "',
                year: '" . $year . "',
                go_date: '" . $go_date . "',
                return_date: '" . $return_date . "',
                reason: '" . $reason . "',
                regno: '" . $regno . "'
            };
            document.getElementById('name').value = data.name;
            document.getElementById('branch').value = data.branch;
            document.getElementById('hostelno').value = data.hostel_no;
            document.getElementById('roomno').value = data.room_no;
            document.getElementById('year').value = data.year;
            document.getElementById('go_date').value = data.go_date;
            document.getElementById('return_date').value = data.return_date;
            document.getElementById('purpose').value = data.reason;
            document.getElementById('regno').value = data.regno;

        });
    </script>";
          ?>


          <hr>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="name">Name:</label>
                <div class="mt-2">
                  <img src="data:image/jpeg;base64,<?php echo $image_base64; ?>" alt="Student image" width="150"
                    height="150">
                </div>
                <input type="text" name="name" id="name" class="form-control mt-2" readonly>
              </div>
              <script>
              // Set the src of the image to the base64 encoded string
              var studentImage = document.querySelector('img');
              studentImage.src = '<?php echo $image_base64; ?>';
            </script>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="branch">Branch:</label>
                <input type="text" name="branch" id="branch" class="form-control" readonly>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="hostelno">Hostel No:</label>
            <input type="text" name="hostelno" id="hostelno" class="form-control" readonly>
          </div>

          <div class="form-group">
            <label for="regno">Register number:</label>
            <input type="text" name="regno" id="regno" class="form-control" readonly>
          </div>

          <div class="form-group">
            <label for="roomno">Room No:</label>
            <input type="text" name="roomno" id="roomno" class="form-control" readonly>
          </div>

          <div class="form-group">
            <label for="year">Year:</label>
            <input type="text" name="year" id="year" class="form-control" readonly>
          </div>


          <div class="form-group">
            <label for="purpose">Purpose:</label>
            <input type="text" class="form-control" id="purpose" name="purpose" placeholder="Enter purpose">
          </div>
          <div class="form-group">
            <label for="date">Date of leaving:</label>
            <input type="date" class="form-control" name="go_date" id="go_date">
          </div>
          <div class="form-group">
            <label for="date">Date of returning:</label>
            <input type="date" class="form-control" name="return_date" id="return_date">
          </div>

          <hr>

          <button type="submit">Save</button>
        </form>

      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>

</html>