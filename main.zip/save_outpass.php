<?php
session_start();

$out_no = $_GET["out_no"];
$date = $_POST["return_date"];

$servername = "localhost";
$username = "root";
$password = "pass123";
$dbname = "db2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed" . $conn->connect_error);
}

$sql = "UPDATE outpass SET return_date = '$date' WHERE out_no = $out_no";
$result = $conn->query($sql);

if ($result === TRUE) {
    echo "<script>alert('Record updated successfully'); window.location.replace('dashboard-home.php');</script>";
    exit; // make sure to exit the script after the redirect
}

mysqli_close($conn);
?>