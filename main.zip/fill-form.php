<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
  <title>fill form</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="dashboard-home.php?v=<?php echo time(); ?>">DASHBOARD</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a href="login.php?v=<?php echo time(); ?>"><button class="btn btn-primary"
              id="login-button">Logout</button></a>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-4">
        <a href="dashboard-home.php?v=<?php echo time(); ?>" type="button" class="btn btn-secondary btn-block mb-3"><i
            class="fas fa-arrow-left mr-2"></i>Back</a>
        <!-- submit button later -->
        <form method="POST" action="submit.php?v=<?php echo time(); ?>">

          <?php
          session_start();
          $email = $_SESSION["username"];

          $servername = "localhost";
          $username = "root";
          $password = "pass123";
          $dbname = "db2";
          $conn = new mysqli($servername, $username, $password, $dbname);

          if ($conn->connect_error) {
            die("Connection failed" . $conn->connect_error);
          }
          $query = "SELECT regno,image FROM student WHERE email = '$email'";
          $result = mysqli_query($conn, $query);

          if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $regno = $row["regno"];
            $image = $row["image"];
          }
          $image_type = pathinfo($image, PATHINFO_EXTENSION);
          $image_data = file_get_contents($image);
          $image_base64 = 'data:image/' . $image_type . ';base64,' . base64_encode($image_data);
          ?>


          <script>


            window.addEventListener("load", function () {
              // Your code to fetch the data goes here
              var regno = <?php echo $regno ?>;

              // Make AJAX request to fetch-data.php
              var xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                  var data = JSON.parse(this.responseText);
                  document.getElementById("name").value = data.name;
                  document.getElementById("branch").value = data.branch;
                  document.getElementById("hostelno").value = data.hostel_no;
                  document.getElementById("roomno").value = data.room_no;
                  document.getElementById("year").value = data.year;
                  document.getElementById("regno").value = data.regno;
                }
              };
              xhttp.open("POST", "fetch-data.php?v=<?php echo time(); ?>", true);
              xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
              xhttp.send("regno=" + regno);
            });


          </script>

          <hr>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group d-flex flex-column align-items-center">
                <label for="name">Name:</label>
                <div class="mt-2">
                  <img src="data:image/jpeg;base64,<?php echo $image_base64; ?>" alt="Student image" width="150"
                    height="150">
                </div>
                <input type="text" name="name" id="name" class="form-control mt-2" readonly>
              </div>
            </div>
            <script>
              // Set the src of the image to the base64 encoded string
              var studentImage = document.querySelector('img');
              studentImage.src = '<?php echo $image_base64; ?>';
            </script>
            <div class="col-md-6">
              <div class="form-group">
                <label for="branch">Branch:</label>
                <input type="text" name="branch" id="branch" class="form-control" readonly>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="hostelno">Hostel No:</label>
            <input type="text" name="hostelno" id="hostelno" class="form-control" readonly>
          </div>

          <div class="form-group">
            <label for="regno">Register Number:</label>
            <input type="text" name="regno" id="regno" class="form-control" readonly>
          </div>

          <div class="form-group">
            <label for="roomno">Room No:</label>
            <input type="text" name="roomno" id="roomno" class="form-control" readonly>
          </div>

          <div class="form-group">
            <label for="year">Year:</label>
            <input type="text" name="year" id="year" class="form-control" readonly>
          </div>


          <div class="form-group">
            <label for="purpose">Purpose:</label>
            <input type="text" class="form-control" id="purpose" name="purpose" placeholder="Enter purpose">
          </div>
          <div class="form-group">
            <label for="date">Date of leaving:</label>
            <input type="date" class="form-control" name="go_date" id="date">
          </div>
          <div class="form-group">
            <label for="date">Date of returning:</label>
            <input type="date" class="form-control" name="return_date" id="date">
          </div>

          <hr>

          <button type="submit">Submit</button>
        </form>

      </div>
    </div>
  </div>


  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>

</html>