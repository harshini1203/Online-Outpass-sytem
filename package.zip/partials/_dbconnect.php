<?php
$server="localhost";
$username="root";
$password="pass123";
$database="db2";
$conn=mysqli_connect($server,$username,$password,$database);
if(!$conn){
    die("Error: " . mysqli_connect_error());
}
?>
